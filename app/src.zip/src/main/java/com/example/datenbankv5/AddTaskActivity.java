package com.example.datenbankv5;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

import com.example.datenbankv5.R;
import com.example.datenbankv5.TodoDatabaseHelper;

public class AddTaskActivity extends AppCompatActivity {

    private TodoDatabaseHelper dbHelper; // Datenbank-Helferklasse

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        dbHelper = new TodoDatabaseHelper(this);

        // Eingabefelder und Button initialisieren
        EditText editTextTask = findViewById(R.id.editTextTask);
        EditText editTextDescription = findViewById(R.id.editTextDescription);
        CheckBox checkBoxUrgent = findViewById(R.id.checkBoxUrgent);
        CheckBox checkBoxImportant = findViewById(R.id.checkBoxImportant);
        Button buttonSaveTask = findViewById(R.id.buttonSaveTask);


        buttonSaveTask.setOnClickListener(v -> {
            // Liest die Eingabewerte aus den EditText-Feldern
            String task = editTextTask.getText().toString();
            String description = editTextDescription.getText().toString();
            boolean isUrgent = checkBoxUrgent.isChecked();
            boolean isImportant = checkBoxImportant.isChecked();

            if (!task.isEmpty() && !description.isEmpty()) {
                dbHelper.insertTask(task, description, isUrgent, isImportant); // Fügt Aufgabe zur Datenbank hinzu
                finish(); // Beendet die Aktivität und kehrt zur MainActivity zurück
            }
        });
    }
}
