package com.example.datenbankv5;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.datenbankv5.R;
import com.example.datenbankv5.TaskAdapter;
import com.example.datenbankv5.TodoDatabaseHelper;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;
public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabAddTask;
    private TaskAdapter taskAdapter;
    private List<Task> taskList;
    private TodoDatabaseHelper dbHelper;

    RecyclerView recyclerViewUrgentImportant;
    RecyclerView recyclerViewNotUrgentImportant;
    RecyclerView recyclerViewUrgentNotImportant;
    RecyclerView recyclerViewNotUrgentNotImportant;

    // Listen und Adapter erstellen
    List<Task> taskListUrgentImportant = new ArrayList<>();
    List<Task> taskListNotUrgentImportant = new ArrayList<>();
    List<Task> taskListUrgentNotImportant = new ArrayList<>();
    List<Task> taskListNotUrgentNotImportant = new ArrayList<>();

    TaskAdapter adapterUrgentImportant;
    TaskAdapter adapterNotUrgentImportant;
    TaskAdapter adapterUrgentNotImportant;
    TaskAdapter adapterNotUrgentNotImportant;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewUrgentImportant = findViewById(R.id.recyclerViewUrgentImportant);
        recyclerViewNotUrgentImportant = findViewById(R.id.recyclerViewNotUrgentImportant);
        recyclerViewUrgentNotImportant = findViewById(R.id.recyclerViewUrgentNotImportant);
        recyclerViewNotUrgentNotImportant = findViewById(R.id.recyclerViewNotUrgentNotImportant);

        adapterUrgentImportant = new TaskAdapter(this, taskListUrgentImportant);
        adapterNotUrgentImportant = new TaskAdapter(this, taskListNotUrgentImportant);
        adapterUrgentNotImportant = new TaskAdapter(this, taskListUrgentNotImportant);
        adapterNotUrgentNotImportant = new TaskAdapter(this, taskListNotUrgentNotImportant);

        recyclerViewUrgentImportant.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewNotUrgentImportant.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewUrgentNotImportant.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewNotUrgentNotImportant.setLayoutManager(new LinearLayoutManager(this));

        recyclerViewUrgentImportant.setAdapter(adapterUrgentImportant);
        recyclerViewNotUrgentImportant.setAdapter(adapterNotUrgentImportant);
        recyclerViewUrgentNotImportant.setAdapter(adapterUrgentNotImportant);
        recyclerViewNotUrgentNotImportant.setAdapter(adapterNotUrgentNotImportant);


        dbHelper = new TodoDatabaseHelper(this);
        // Initialize FloatingActionButton
        fabAddTask = findViewById(R.id.fabAddTask);
        loadTasksFromDatabase();


        // FloatingActionButton click
        fabAddTask.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddTaskActivity.class);
            startActivity(intent);
        });
    }

    // Load tasks from database
    private void loadTasksFromDatabase() {
        taskList.clear();
        Cursor cursor = dbHelper.getAllTasks();

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    String title = cursor.getString(cursor.getColumnIndexOrThrow("task"));
                    String description = cursor.getString(cursor.getColumnIndexOrThrow("description"));
                    taskList.add(new Task(title, description));
                }
            } finally {
                cursor.close(); // Wichtig: Cursor schließen
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadTasksFromDatabase();
        taskAdapter.notifyDataSetChanged();
    }
}
